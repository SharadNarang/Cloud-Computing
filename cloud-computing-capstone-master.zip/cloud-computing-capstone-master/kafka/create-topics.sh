$KAFKA_HOME/bin/kafka-topics.sh --zookeeper localhost:2181 --create --topic ontime --partitions 42 --replication-factor 1
$KAFKA_HOME/bin/kafka-topics.sh --zookeeper localhost:2181 --create --topic 2008ontime --partitions 42 --replication-factor 1
