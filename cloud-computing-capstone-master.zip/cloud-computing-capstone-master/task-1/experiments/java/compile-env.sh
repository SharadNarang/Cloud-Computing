export JAVA_HOME=/usr/jdk64/jdk1.7.0_67
export HADOOP_CLASSPATH=${JAVA_HOME}/lib/tools.jar

