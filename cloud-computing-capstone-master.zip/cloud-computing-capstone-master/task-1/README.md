# cloud-computing-casptone

## Main shell scripts

Tests integrating all steps required for answering a question.

## Pig scripts

Hadoop tasks in Pig Latin.

## CQL scripts

Scripts for setting up and loading data in Cassandra
